package com.graphql.graphql.controller

import com.graphql.graphql.dto.ProductDto
import com.graphql.graphql.service.ProductService
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/products")
class ProductController(private val productService: ProductService) {

    @PostMapping("/create")
    fun createProduct(@RequestBody product: ProductDto): ResponseEntity<ProductDto> {
        val savedProduct = productService.createProduct(product)
        return ResponseEntity(savedProduct, HttpStatus.CREATED)
    }
    @GetMapping("/hello")
    fun hello(): String{
        return "hello world"
    }
}
