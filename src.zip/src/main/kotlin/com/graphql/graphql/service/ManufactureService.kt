package com.graphql.graphql.service

import com.graphql.graphql.dto.ManufacturerDto

interface ManufactureService {
    fun getManufacturerByName(name: String): ManufacturerDto
    fun findAll(): List<String>
}
