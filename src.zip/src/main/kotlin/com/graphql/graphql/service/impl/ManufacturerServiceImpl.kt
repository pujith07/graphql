package com.graphql.graphql.service.impl

import com.graphql.graphql.dto.ManufacturerDto
import com.graphql.graphql.mapper.ManufacturerMapper
import com.graphql.graphql.repository.ManufacturerRepository
import com.graphql.graphql.service.ManufactureService
import jakarta.annotation.PostConstruct
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.stereotype.Service


@Service
class ManufacturerServiceImpl(
    private val manufacturerRepository: ManufacturerRepository,
    private val manufacturerMapper: ManufacturerMapper,
    private val jdbcTemplate: JdbcTemplate? = null

) : ManufactureService {
    

    override fun getManufacturerByName(name: String): ManufacturerDto {
        val manufacturerList = manufacturerRepository.findByManufactureName(name)
        val manufacturerDto= mutableListOf<ManufacturerDto>()
        manufacturerList.forEach { manufacturer ->
            manufacturerDto.add(manufacturerMapper.convertToDto(manufacturer)) }
        return manufacturerDto.first()
    }

    override fun findAll(): List<String> {
        val manufacturerList = manufacturerRepository.findAll()
        val list= mutableListOf<String>()
        manufacturerList.forEach { manufacturer ->
            list.add(manufacturer.manufactureName) }
        return list
    }
    @PostConstruct
    fun insertData() {
        val sql =
            "INSERT INTO manufacturer (manufacture_id, manufacture_name, manufacture_origin, user_ratings, no_of_products_available, annual_revenue) VALUES (?, ?, ?, ?, ?, ?)"
        jdbcTemplate!!.update(sql, "1", "Manufacture A", "Usa", 4.5, 500, 1000000.0)
        jdbcTemplate.update(sql, "2", "Manufacture B", "Japan", 4.2, 300, 800000.0)
        jdbcTemplate.update(sql, "3", "Manufacture C", "Italy", 4.2, 300, 800000.0)


    }
}
