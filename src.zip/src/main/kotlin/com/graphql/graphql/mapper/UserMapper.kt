package com.graphql.graphql.mapper

import com.graphql.graphql.dto.UserDto
import com.graphql.graphql.model.User
import org.modelmapper.ModelMapper
import org.springframework.stereotype.Service

@Service
class UserMapper(private val modelMapper: ModelMapper) {

    fun convertToDto(user:User):UserDto{
        return modelMapper.map(user,UserDto::class.java)
    }

    fun convertToEntity(userDto:UserDto):User{
        return modelMapper.map(userDto,User::class.java)
    }
}