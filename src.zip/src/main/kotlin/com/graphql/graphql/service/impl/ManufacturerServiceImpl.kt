package com.graphql.graphql.service.impl

import com.graphql.graphql.dto.ManufacturerDto
import com.graphql.graphql.mapper.ManufacturerMapper
import com.graphql.graphql.repository.ManufacturerRepository
import com.graphql.graphql.service.ManufactureService
import org.springframework.stereotype.Service

@Service
class ManufacturerServiceImpl(
    private val manufacturerRepository: ManufacturerRepository,
    private val manufacturerMapper: ManufacturerMapper
) : ManufactureService {
    

    override fun getManufacturerByName(name: String): ManufacturerDto {
        val manufacturerList = manufacturerRepository.findByManufactureName(name)
        val manufacturerDto= mutableListOf<ManufacturerDto>()
        manufacturerList.forEach { manufacturer ->
            manufacturerDto.add(manufacturerMapper.convertToDto(manufacturer)) }
        return manufacturerDto.first()
    }

    override fun findAll(): List<String> {
        val manufacturerList = manufacturerRepository.findAll()
        val list= mutableListOf<String>()
        manufacturerList.forEach { manufacturer ->
            list.add(manufacturer.manufactureName) }
        return list
    }
}
