package com.graphql.graphql.service

import com.graphql.graphql.dto.ProductDto

interface ProductService {
    fun getProductByName(name: String): List<ProductDto>
    fun createProduct(productDto: ProductDto): ProductDto
}
