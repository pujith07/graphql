package com.graphql.graphql.mapper

import com.graphql.graphql.dto.ProductDto
import com.graphql.graphql.model.Product
import org.springframework.stereotype.Service

@Service
class ProductMapper {

    fun convertToDto(product: Product): ProductDto {
        return ProductDto(
            product.productId,
            product.productName,
            product.productType,
            product.manufacturer,
            product.unitSoldSoFar,
            product.price
        )
    }

    fun convertToEntity(productDto: ProductDto): Product {
        return Product(
            productDto.productId,
            productDto.productName,
            productDto.productType,
            productDto.manufacturer,
            productDto.unitSoldSoFar,
            productDto.price
        )
    }
}