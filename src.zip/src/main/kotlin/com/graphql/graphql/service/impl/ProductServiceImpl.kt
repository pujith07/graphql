package com.graphql.graphql.service.impl

import com.graphql.graphql.dto.ProductDto
import com.graphql.graphql.mapper.ProductMapper
import com.graphql.graphql.repository.ProductRepository
import com.graphql.graphql.service.ProductService
import jakarta.annotation.PostConstruct
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.stereotype.Service

@Service
class ProductServiceImpl(
    private val productRepository: ProductRepository,
    private val productMapper: ProductMapper,
    private var jdbcTemplate: JdbcTemplate
) : ProductService {

    override fun getProductByName(name: String): List<ProductDto> {
        val productList = productRepository.findByProductNameContaining(name)
        val productDto= mutableListOf<ProductDto>()
        productList.forEach { product -> productDto.add(productMapper.convertToDto(product)) }
        return productDto
    }

    override fun createProduct(productDto: ProductDto): ProductDto {
        var productEntity = productMapper.convertToEntity(productDto)
        productEntity = productRepository.save(productEntity)
        return productMapper.convertToDto(productEntity)
    }

    @PostConstruct
    fun insertData() {
        val sql = "INSERT INTO product (product_id,product_name, product_type, manufacturer, unit_sold_so_far, price) VALUES (?, ?, ?, ?, ?,?)"

        jdbcTemplate.update(sql, "1","Product 1", "Shoe", "Manufacture A", 100, 50.0f)
        jdbcTemplate.update(sql, "2","Product 2", "Cap", "Manufacture B", 200, 75.0f)
        jdbcTemplate.update(sql, "3","Product 3", "Sandals", "Manufacture C", 150, 60.0f)

        // Add more dummy data as needed
    }
}

