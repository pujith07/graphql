package com.graphql.graphql.controller


import com.graphql.graphql.dto.ManufacturerDto
import com.graphql.graphql.dto.ProductDto
import com.graphql.graphql.service.ManufactureService
import com.graphql.graphql.service.ProductService
import org.springframework.graphql.data.method.annotation.Argument
import org.springframework.graphql.data.method.annotation.QueryMapping
import org.springframework.stereotype.Controller

@Controller
class GraphQLController (private val productService: ProductService,
private val manufactureService: ManufactureService,
){

    @QueryMapping
    fun searchProductByName(@Argument name: String): List<ProductDto> =
        productService.getProductByName(name)

    @QueryMapping
    fun getManufacturers(): List<String> = manufactureService.findAll()

    @QueryMapping
    fun getManufacturerByName(@Argument name: String): ManufacturerDto =
        manufactureService.getManufacturerByName(name)
}

