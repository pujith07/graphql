package com.graphql.graphql.service

import com.graphql.graphql.dto.UserDto

interface UserService {
    fun saveUser(user: UserDto): UserDto?
    fun validateUser(username: String, password: String): UserDto?
}
