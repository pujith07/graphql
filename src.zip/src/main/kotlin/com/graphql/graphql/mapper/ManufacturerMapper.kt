package com.graphql.graphql.mapper

import com.graphql.graphql.dto.ManufacturerDto
import com.graphql.graphql.model.Manufacturer
import org.modelmapper.ModelMapper
import org.springframework.stereotype.Service

@Service
class ManufacturerMapper(private val modelMapper: ModelMapper) {

    fun convertToDto(manufacturer:Manufacturer):ManufacturerDto{
        return modelMapper.map(manufacturer,ManufacturerDto::class.java)
    }

    fun convertToEntity(manufacturerDto:ManufacturerDto):Manufacturer{
        return modelMapper.map(manufacturerDto,Manufacturer::class.java)
    }
}