package com.graphql.graphql.mapper

import com.graphql.graphql.dto.UserDto
import com.graphql.graphql.model.User
import org.modelmapper.ModelMapper
import org.springframework.stereotype.Service

@Service
class UserMapper {

    fun convertToDto(user:User):UserDto{
        return UserDto(user.userId,user.firstName,user.lastName,user.gender,user.email,user.contact,user.password)
    }

    fun convertToEntity(userDto:UserDto):User{
        return User(userDto.userId,userDto.firstName,userDto.lastName,userDto.gender,userDto.email,userDto.contact,userDto.password)
    }
}