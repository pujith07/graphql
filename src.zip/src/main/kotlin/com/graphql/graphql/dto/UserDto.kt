package com.graphql.graphql.dto

data class UserDto(
    var userId: Long = 0,
    var firstName: String = "",
    var lastName: String = "",
    var gender: String = "",
    var email: String = "",
    var contact: String = "",
    var password: String = ""
)
