package com.graphql.graphql.controller

import com.graphql.graphql.dto.UserDto
import com.graphql.graphql.service.UserService
import jakarta.validation.constraints.Email
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*


@RestController
@RequestMapping("/users")
class UserController(private val userService: UserService) {

    @PostMapping("/save")
    fun saveUser(@RequestBody user: UserDto): ResponseEntity<UserDto> {
        val savedUser = userService.saveUser(user)
        return ResponseEntity.status(HttpStatus.CREATED).body(savedUser)
    }

    @GetMapping("/validate-login")
    fun validateUser(@RequestParam userName: String, @RequestParam password: String): ResponseEntity<Boolean> {
        val user = userService.validateUser(userName, password)
        return ResponseEntity.ok(user)
    }
}
