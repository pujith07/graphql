package com.graphql.graphql.model

import jakarta.persistence.*

@Entity
@Table(name = "product")
data class Product(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var productId: Int = 0,
    val productName: String,
    val productType: String,
    val manufacturer: String,
    val unitSoldSoFar: Int,
    val price: Float
)
