package com.graphql.graphql.service.impl

import com.graphql.graphql.dto.UserDto
import com.graphql.graphql.mapper.UserMapper
import com.graphql.graphql.repository.UserRepository
import com.graphql.graphql.service.UserService
import org.springframework.stereotype.Service
import java.io.IOException
import java.util.regex.Pattern


@Service
class UserServiceImpl(
    private val userRepository: UserRepository,
    private val userMapper: UserMapper
) : UserService {

    override fun saveUser(user: UserDto): UserDto? {
        if (!isEmailValid(user.email)) {
            throw IOException("Invalid Email Address")
        }

        // Generate password as specified
        val password = user.contact + user.firstName
        user.password = password
        var userDto = userMapper.convertToEntity(user)
        userDto = userRepository.save(userDto);
        return userMapper.convertToDto(userDto)
    }


    override fun validateUser(username: String, password: String): UserDto? {
        val user = userRepository.findByEmail(username)
        var userDto= UserDto()
        if (user != null) {
            userDto = userMapper.convertToDto(user)
        }
        return if (user?.password == password) userDto else null
    }

    fun isEmailValid(email: String): Boolean {
        return Pattern.compile(
            "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]|[\\w-]{2,}))@"
                    + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                    + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                    + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                    + "[0-9]{1,2}|25[0-5]|2[0-4][0-9]))|"
                    + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$"
        ).matcher(email).matches()
    }
}
