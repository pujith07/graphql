package com.graphql.graphql.dto

data class ProductDto(
    val productId: Int = 0,
    val productName: String,
    val productType: String,
    val manufacturer: String,
    val unitSoldSoFar: Int,
    val price: Float
)
