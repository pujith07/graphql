package com.graphql.graphql.mapper

import com.graphql.graphql.dto.ProductDto
import com.graphql.graphql.model.Product
import org.modelmapper.ModelMapper
import org.springframework.stereotype.Service

@Service
class ProductMapper(private val modelMapper: ModelMapper) {

    fun convertToDto(product:Product):ProductDto{
        return modelMapper.map(product,ProductDto::class.java)
    }

    fun convertToEntity(productDto:ProductDto):Product{
        return modelMapper.map(productDto,Product::class.java)
    }
}