package com.graphql.graphql.service.impl

import com.graphql.graphql.dto.ProductDto
import com.graphql.graphql.mapper.ProductMapper
import com.graphql.graphql.model.Product
import com.graphql.graphql.repository.ProductRepository
import com.graphql.graphql.service.ProductService
import org.springframework.stereotype.Service

@Service
class ProductServiceImpl(
    private val productRepository: ProductRepository,
    private val productMapper: ProductMapper
) : ProductService {

    override fun getProductByName(name: String): List<ProductDto> {
        val productList = productRepository.findByProductNameContaining(name)
        val productDto= mutableListOf<ProductDto>()
        productList.forEach { product -> productDto.add(productMapper.convertToDto(product)) }
        return productDto
    }

    override fun createProduct(productDto: ProductDto): ProductDto {
        var productEntity = productMapper.convertToEntity(productDto)
        productEntity = productRepository.save(productEntity)
        return productMapper.convertToDto(productEntity)
    }
}
