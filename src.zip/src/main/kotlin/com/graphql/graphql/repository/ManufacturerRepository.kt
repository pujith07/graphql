package com.graphql.graphql.repository

import com.graphql.graphql.model.Manufacturer
import org.springframework.data.jpa.repository.JpaRepository

interface ManufacturerRepository : JpaRepository<Manufacturer, Int> {
    fun findByManufactureName(manufactureName: String): List<Manufacturer>
}
