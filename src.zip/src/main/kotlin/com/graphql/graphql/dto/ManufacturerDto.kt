package com.graphql.graphql.dto

data class ManufacturerDto(
    var manufactureId: Int = 0,
    val manufactureName: String,
    val manufactureOrigin: String,
    val userRatings: Float,
    val noOfProductsAvailable: Int,
    val annualRevenue: Double
)
