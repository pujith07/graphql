package com.graphql.graphql.mapper

import com.graphql.graphql.dto.ManufacturerDto
import com.graphql.graphql.model.Manufacturer
import org.modelmapper.ModelMapper
import org.springframework.stereotype.Service

@Service
class ManufacturerMapper {

    fun convertToDto(manufacturer: Manufacturer): ManufacturerDto {
        return ManufacturerDto(
            manufacturer.manufactureId,
            manufacturer.manufactureName,
            manufacturer.manufactureOrigin,
            manufacturer.userRatings,
            manufacturer.noOfProductsAvailable,
            manufacturer.annualRevenue
        )
    }

    fun convertToEntity(manufacturerDto: ManufacturerDto): Manufacturer {
        return Manufacturer(
            manufacturerDto.manufactureId,
            manufacturerDto.manufactureName,
            manufacturerDto.manufactureOrigin,
            manufacturerDto.userRatings,
            manufacturerDto.noOfProductsAvailable,
            manufacturerDto.annualRevenue
        )
    }
}